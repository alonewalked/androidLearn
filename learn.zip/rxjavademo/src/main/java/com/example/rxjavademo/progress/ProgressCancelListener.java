package com.example.rxjavademo.progress;

/**
 * Created by tj on 2017/10/16.
 */

public interface ProgressCancelListener {

    void onCancelProgress();
}
