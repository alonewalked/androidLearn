package com.example.rxjavademo.progress;

/**
 * Created by tj on 2017/10/16.
 */

public interface ObserverOnNextListener<T> {
    void onNext(T t);
}
