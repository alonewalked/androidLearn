package com.example.rxjavademo.base;

/**
 * Created by tj on 2017/10/16.
 */

public interface BaseView {

}
