package com.example.mixerframework;

/**
 * Created by tj on 2017/10/25.
 */

public class LHConstant {

    public static final String KEY_INTENT_EXTRA_URL = "KEY_INTENT_EXTRA_URL";

    public static final String IS_BG_TRANSPARENT = "bgTransparent";
    public static final String IS_DEBUG_MODE = "isDebugMode";

}


