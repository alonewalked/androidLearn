package com.example.mixerframework.loadstatus;

/**
 * Created by tj on 2017/10/25.
 */

public interface IReload {
    /**
     * 重新加载页面
     */
    void onRefreshClick();
}
